// === DOM Elements ===
const ownBoard = document.getElementById("ownBoard");
const opponentBoard = document.getElementById("opponentBoard");
const dock = document.getElementById("dock");
const info = document.getElementById("info");
const resetBtn = document.getElementById("resetBtn");
const toggleSoundBtn = document.getElementById("toggleSoundBtn");
const soundHit = document.getElementById("soundHit");
const soundMiss = document.getElementById("soundMiss");

// === Game Setup ===
const boardSize = 10;
const duckSizes = [
  { size: 5, color: "green", id: "green1" },
  { size: 4, color: "green", id: "green2" },
  { size: 3, color: "blue", id: "blue1" },
  { size: 3, color: "blue", id: "blue2" },
  { size: 2, color: "yellow", id: "yellow1" },
];

let boards = {
  1: createEmptyBoard(),
  2: createEmptyBoard(),
};

let placedDucks = { 1: [], 2: [] };
let hits = { 1: [], 2: [] };

let draggingDuck = null;
let currentPlacingPlayer = 1;
let gameStarted = false;
let currentPlayer = null;
let soundEnabled = true;
let dragGhost = null;
let lastHoverCell = null;

// === Helper Functions ===
function createEmptyBoard() {
  return Array.from({ length: boardSize }, () =>
    Array(boardSize).fill(null)
  );
}

function createBoardElements(boardEl) {
  boardEl.innerHTML = "";
  for (let y = 0; y < boardSize; y++) {
    for (let x = 0; x < boardSize; x++) {
      const cell = document.createElement("div");
      cell.classList.add("cell");
      cell.dataset.x = x;
      cell.dataset.y = y;
      boardEl.appendChild(cell);
    }
  }
}

function renderBoard(boardEl, boardData, showDucks = false) {
  const cells = boardEl.querySelectorAll(".cell");
  cells.forEach((cell) => {
    const x = +cell.dataset.x;
    const y = +cell.dataset.y;
    const val = boardData[y][x];
    cell.innerHTML = "";
    cell.classList.remove("hit", "miss", "highlight", "sunk");

    if (gameStarted && boardEl === opponentBoard) {
      const hit = hits[currentPlayer].find(h => h.x === x && h.y === y);
      if (hit) {
        if (val) {
          cell.classList.add("hit");
          const emoji = document.createElement("div");
          emoji.textContent = "🦆";
          emoji.classList.add("duck-emoji");
          cell.appendChild(emoji);
          setTimeout(() => emoji.remove(), 700);
        } else {
          cell.classList.add("miss");
        }
      }
    }

    if (showDucks && val) {
      const duck = document.createElement("div");
      duck.classList.add("duck", val.color, val.id);
      cell.appendChild(duck);
    }
  });
}

function canPlaceDuck(board, x, y, size, horizontal) {
  if (horizontal ? x + size > boardSize : y + size > boardSize) return false;

  for (let dy = -1; dy <= (horizontal ? 1 : size); dy++) {
    for (let dx = -1; dx <= (horizontal ? size : 1); dx++) {
      let nx = x + dx;
      let ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= boardSize || ny >= boardSize) continue;
      if (board[ny][nx]) return false;
    }
  }
  return true;
}

function placeDuckOnBoard(board, duck) {
  const { x, y, size, horizontal, color, id } = duck;
  for (let i = 0; i < size; i++) {
    const dx = horizontal ? i : 0;
    const dy = horizontal ? 0 : i;
    board[y + dy][x + dx] = { size, color, id, duck };
  }
}

function removeDuckFromBoard(board, duck) {
  const { x, y, size, horizontal } = duck;
  for (let i = 0; i < size; i++) {
    const dx = horizontal ? i : 0;
    const dy = horizontal ? 0 : i;
    board[y + dy][x + dx] = null;
  }
}

function highlightCells(x, y, size, horizontal) {
  for (let i = 0; i < size; i++) {
    const dx = horizontal ? i : 0;
    const dy = horizontal ? 0 : i;
    const cell = ownBoard.querySelector(`.cell[data-x="${x+dx}"][data-y="${y+dy}"]`);
    if (cell) cell.classList.add("highlight");
  }
}

function clearBoardHighlights() {
  ownBoard.querySelectorAll(".cell").forEach(cell => {
    cell.classList.remove("highlight");
  });
}

function isDuckSunk(enemy, duck) {
  for (let i = 0; i < duck.size; i++) {
    const x = duck.x + (duck.horizontal ? i : 0);
    const y = duck.y + (duck.horizontal ? 0 : i);
    if (!hits[currentPlayer].some(h => h.x === x && h.y === y)) return false;
  }
  return true;
}

function markSurroundingMisses(enemy, duck) {
  const startX = duck.x - 1;
  const startY = duck.y - 1;
  const endX = duck.x + (duck.horizontal ? duck.size : 1);
  const endY = duck.y + (duck.horizontal ? 1 : duck.size);

  for (let y = startY; y <= endY; y++) {
    for (let x = startX; x <= endX; x++) {
      if (x < 0 || y < 0 || x >= boardSize || y >= boardSize) continue;
      if (!boards[enemy][y][x] &&
          !hits[currentPlayer].some(h => h.x === x && h.y === y)) {
        hits[currentPlayer].push({ x, y });
      }
    }
  }
}

function checkWin(enemy) {
  for (let y = 0; y < boardSize; y++) {
    for (let x = 0; x < boardSize; x++) {
      if (boards[enemy][y][x] && !hits[currentPlayer].some(h => h.x === x && h.y === y)) {
        return false;
      }
    }
  }
  return true;
}

// === Gameplay ===
function switchTurn() {
  currentPlayer = currentPlayer === 1 ? 2 : 1;
  info.textContent = `Player ${currentPlayer}'s turn.`;
  renderBoard(ownBoard, boards[currentPlayer], true);
  renderBoard(opponentBoard, boards[currentPlayer === 1 ? 2 : 1], false);
  toggleOpponentBoard(true);
}

function toggleOpponentBoard(enabled) {
  opponentBoard.style.pointerEvents = enabled ? "auto" : "none";
}

function handleAttack(x, y) {
  if (hits[currentPlayer].some(h => h.x === x && h.y === y)) {
    info.textContent = "Already attacked!";
    return;
  }

  const enemy = currentPlayer === 1 ? 2 : 1;
  const target = boards[enemy][y][x];
  hits[currentPlayer].push({ x, y });

  if (target) {
    playSound("hit");
    info.textContent = "Hit!";
    if (isDuckSunk(enemy, target.duck)) {
      info.textContent = `Sunk duck ${target.duck.id}!`;
      markSurroundingMisses(enemy, target.duck);
    }
    renderBoard(opponentBoard, boards[enemy], false);
    renderBoard(ownBoard, boards[currentPlayer], true);

    if (checkWin(enemy)) {
      info.textContent = `Player ${currentPlayer} wins!`;
      toggleOpponentBoard(false);
      gameStarted = false;
    }
  } else {
    playSound("miss");
    info.textContent = "Miss!";
    renderBoard(opponentBoard, boards[enemy], false);
    renderBoard(ownBoard, boards[currentPlayer], true);
    toggleOpponentBoard(false);
    setTimeout(switchTurn, 2000);
  }
}

opponentBoard.addEventListener("click", (e) => {
  if (!gameStarted) return;
  const cell = e.target.closest(".cell");
  if (!cell) return;
  const x = +cell.dataset.x;
  const y = +cell.dataset.y;
  handleAttack(x, y);
});

// === Sound ===
function playSound(type) {
  if (!soundEnabled) return;
  if (type === "hit") soundHit.play();
  else if (type === "miss") soundMiss.play();
}

// === Dock / Drag Logic ===
function setupDock() {
  dock.innerHTML = "";
  duckSizes.forEach(({ size, color, id }) => {
    if (placedDucks[currentPlacingPlayer].some(d => d.id === id)) return;
    const el = document.createElement("div");
    el.classList.add("dock-ship", color);
    el.id = id;
    el.dataset.size = size;
    el.dataset.color = color;
    el.dataset.id = id;
    el.dataset.source = "dock";
    el.addEventListener("mousedown", (e) => {
      startDraggingDuck({ size, color, id, horizontal: true, source: "dock" }, e);
    });
    dock.appendChild(el);
  });
}

function startDraggingDuck(duck, event) {
  draggingDuck = { ...duck };
  createDragGhost(duck);
  moveGhost(event.pageX, event.pageY);
  document.addEventListener("mousemove", onDrag);
  document.addEventListener("mouseup", onDrop);
}

function createDragGhost(duck) {
  if (dragGhost) dragGhost.remove();
  dragGhost = document.createElement("div");
  dragGhost.className = "drag-ghost";
  dragGhost.style.position = "absolute";
  dragGhost.style.display = "grid";
  dragGhost.style.pointerEvents = "none";
  dragGhost.style.zIndex = 9999;
  dragGhost.style.gridTemplateColumns = duck.horizontal
    ? `repeat(${duck.size}, 30px)`
    : "30px";
  dragGhost.style.gridTemplateRows = duck.horizontal
    ? "30px"
    : `repeat(${duck.size}, 30px)`;
  for (let i = 0; i < duck.size; i++) {
    const part = document.createElement("div");
    part.className = `duck ${duck.color}`;
    dragGhost.appendChild(part);
  }
  document.body.appendChild(dragGhost);
}

function moveGhost(x, y) {
  if (dragGhost) {
    dragGhost.style.left = x + 10 + "px";
    dragGhost.style.top = y + 10 + "px";
  }
}

function onDrag(e) {
  moveGhost(e.pageX, e.pageY);
  const cell = document.elementFromPoint(e.clientX, e.clientY)?.closest(".cell");
  if (!cell) return;
  const x = +cell.dataset.x;
  const y = +cell.dataset.y;
  clearBoardHighlights();
  if (canPlaceDuck(boards[currentPlacingPlayer], x, y, draggingDuck.size, draggingDuck.horizontal)) {
    highlightCells(x, y, draggingDuck.size, draggingDuck.horizontal);
  }
}

function onDrop(e) {
  document.removeEventListener("mousemove", onDrag);
  document.removeEventListener("mouseup", onDrop);
  clearBoardHighlights();
  dragGhost?.remove();
  dragGhost = null;

  const cell = document.elementFromPoint(e.clientX, e.clientY)?.closest(".cell");
  if (!cell) return;
  const x = +cell.dataset.x;
  const y = +cell.dataset.y;

  if (!canPlaceDuck(boards[currentPlacingPlayer], x, y, draggingDuck.size, draggingDuck.horizontal)) {
    draggingDuck = null;
    return;
  }

  draggingDuck.x = x;
  draggingDuck.y = y;
  placeDuckOnBoard(boards[currentPlacingPlayer], draggingDuck);
  placedDucks[currentPlacingPlayer].push(draggingDuck);

  renderBoard(ownBoard, boards[currentPlacingPlayer], true);
  setupDock();
  draggingDuck = null;

  if (placedDucks[currentPlacingPlayer].length === duckSizes.length) {
    if (currentPlacingPlayer === 1) {
      currentPlacingPlayer = 2;
      info.textContent = "Player 2, place your ducks.";
      boards[2] = createEmptyBoard();
      placedDucks[2] = [];
      createBoardElements(ownBoard);
      renderBoard(ownBoard, boards[2], true);
      renderBoard(opponentBoard, boards[1], false);
      setupDock();
    } else {
      gameStarted = true;
      currentPlayer = 1;
      info.textContent = "Player 1 begins!";
      dock.innerHTML = "";
      renderBoard(ownBoard, boards[1], true);
      renderBoard(opponentBoard, boards[2], false);
    }
  }
}

// === UI Events ===
resetBtn.addEventListener("click", () => location.reload());

toggleSoundBtn.addEventListener("click", () => {
  soundEnabled = !soundEnabled;
  toggleSoundBtn.textContent = `Sound: ${soundEnabled ? "On" : "Off"}`;
});

document.addEventListener("keydown", e => {
  if (e.key === "r" && draggingDuck) {
    draggingDuck.horizontal = !draggingDuck.horizontal;
    dragGhost?.remove();
    createDragGhost(draggingDuck);
  }
});

ownBoard.addEventListener("mousedown", e => {
  if (gameStarted) return;
  const cell = e.target.closest(".cell");
  if (!cell) return;
  const x = +cell.dataset.x;
  const y = +cell.dataset.y;
  const val = boards[currentPlacingPlayer][y][x];
  if (!val) return;
  const duck = placedDucks[currentPlacingPlayer].find(d => d.id === val.id);
  if (!duck) return;
  removeDuckFromBoard(boards[currentPlacingPlayer], duck);
  placedDucks[currentPlacingPlayer] = placedDucks[currentPlacingPlayer].filter(d => d.id !== duck.id);
  renderBoard(ownBoard, boards[currentPlacingPlayer], true);
  setupDock();
  startDraggingDuck({ ...duck, source: "board" }, e);
});

// === Init ===
function init() {
  createBoardElements(ownBoard);
  createBoardElements(opponentBoard);
  renderBoard(ownBoard, boards[1], true);
  renderBoard(opponentBoard, boards[2], true);
  setupDock();
  info.textContent = "Player 1: place your ducks.";
}
init();
